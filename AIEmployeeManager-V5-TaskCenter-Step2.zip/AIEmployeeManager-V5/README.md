# AIEmployeeManager-V5

AI员工管家 V5.0 Android App

## V5 第一阶段目标
- AI总管（任务分析与调度）
- AI员工管理
- 任务中心
- 工作记录
- AI会计师（收入、支出、税务资料准备）
- 数据备份

这是第一版项目骨架，用于 GitHub 备份和后续持续开发。
