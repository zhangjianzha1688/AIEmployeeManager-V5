package com.aiemployeemanager.v5.brain

object EmployeeRegistry {

    fun employeeFor(type: TaskType): String = when (type) {
        TaskType.DEVELOPMENT -> "AI开发员工"
        TaskType.ACCOUNTING -> "AI会计师"
        TaskType.CONTENT -> "AI内容员工"
        TaskType.RESEARCH -> "AI研究员工"
        TaskType.MANAGEMENT -> "AI任务管理员"
        TaskType.UNKNOWN -> "AI总管"
    }
}
