package com.aiemployeemanager.v5.brain

class AIManagerBrain {

    fun analyze(command: String): AITask {
        val type = classify(command)
        return AITask(
            id = "TASK-" + System.currentTimeMillis(),
            userCommand = command,
            type = type,
            assignedEmployee = EmployeeRegistry.employeeFor(type),
            status = TaskStatus.RECEIVED
        )
    }

    private fun classify(command: String): TaskType {
        val text = command.lowercase()

        return when {
            listOf("代码", "开发", "程序", "app", "软件").any { it in text } ->
                TaskType.DEVELOPMENT
            listOf("收入", "支出", "账", "税", "报税", "会计").any { it in text } ->
                TaskType.ACCOUNTING
            listOf("视频", "youtube", "文章", "内容", "图片").any { it in text } ->
                TaskType.CONTENT
            listOf("搜索", "研究", "分析", "查询", "资料").any { it in text } ->
                TaskType.RESEARCH
            listOf("任务", "安排", "计划", "管理").any { it in text } ->
                TaskType.MANAGEMENT
            else -> TaskType.UNKNOWN
        }
    }
}
