package com.aiemployeemanager.v5.brain

class TaskRepository {
    private val tasks = mutableStateListOf<AITask>()

    fun add(task: AITask) {
        tasks.add(task)
    }

    fun all(): List<AITask> = tasks.toList()

    fun updateStatus(taskId: String, newStatus: TaskStatus) {
        val index = tasks.indexOfFirst { it.id == taskId }
        if (index >= 0) {
            tasks[index] = tasks[index].copy(status = newStatus)
        }
    }
}
