package com.aiemployeemanager.v5

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.aiemployeemanager.v5.brain.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AIEmployeeManagerApp() }
    }
}

@Composable
fun AIEmployeeManagerApp() {
    var page by remember { mutableStateOf("总览") }
    var command by remember { mutableStateOf("") }
    val brain = remember { AIManagerBrain() }
    val repository = remember { TaskRepository() }

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("AI员工管家 V5") }) },
            bottomBar = {
                NavigationBar {
                    listOf("总览", "AI员工", "任务", "会计").forEach { item ->
                        NavigationBarItem(
                            selected = page == item,
                            onClick = { page = item },
                            icon = { Text("●") },
                            label = { Text(item) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                modifier = Modifier.padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                when (page) {
                    "任务" -> TaskCenter(repository)
                    "AI员工" -> EmployeeCenter()
                    "会计" -> AccountantPlaceholder()
                    else -> ManagerDashboard(
                        command = command,
                        onCommandChange = { command = it },
                        onCreateTask = {
                            if (command.isNotBlank()) {
                                repository.add(brain.analyze(command))
                                command = ""
                                page = "任务"
                            }
                        },
                        taskCount = repository.all().size
                    )
                }
            }
        }
    }
}

@Composable
fun ManagerDashboard(
    command: String,
    onCommandChange: (String) -> Unit,
    onCreateTask: () -> Unit,
    taskCount: Int
) {
    Text("🧠 AI总管", style = MaterialTheme.typography.headlineMedium)
    Text("当前共有 $taskCount 个任务。输入命令后，AI总管会自动分配员工。")

    OutlinedTextField(
        value = command,
        onValueChange = onCommandChange,
        label = { Text("例如：帮我整理本月收入和支出") },
        modifier = Modifier.fillMaxWidth()
    )

    Button(onClick = onCreateTask, modifier = Modifier.fillMaxWidth()) {
        Text("创建并分配任务")
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("V5 工作流程")
            Text("1. 接收命令")
            Text("2. AI分析")
            Text("3. 自动分配员工")
            Text("4. 跟踪任务进度")
            Text("5. 完成并保存记录")
        }
    }
}

@Composable
fun TaskCenter(repository: TaskRepository) {
    val tasks = repository.all()

    Text("📋 任务中心", style = MaterialTheme.typography.headlineMedium)
    Text("这里可以查看 AI员工正在处理的任务。")

    if (tasks.isEmpty()) {
        Card(modifier = Modifier.fillMaxWidth()) {
            Text(
                "暂无任务。请返回“总览”，让 AI总管创建第一个任务。",
                modifier = Modifier.padding(20.dp)
            )
        }
    } else {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(tasks, key = { it.id }) { task ->
                TaskCard(task = task, repository = repository)
            }
        }
    }
}

@Composable
fun TaskCard(task: AITask, repository: TaskRepository) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(task.userCommand, style = MaterialTheme.typography.titleMedium)
            Text("负责员工：${task.assignedEmployee}")
            Text("类型：${task.type}")
            Text("状态：${statusText(task.status)}")

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (task.status == TaskStatus.RECEIVED) {
                    Button(onClick = {
                        repository.updateStatus(task.id, TaskStatus.ANALYZING)
                    }) { Text("开始分析") }
                }

                if (task.status == TaskStatus.ANALYZING) {
                    Button(onClick = {
                        repository.updateStatus(task.id, TaskStatus.WORKING)
                    }) { Text("开始执行") }
                }

                if (task.status == TaskStatus.WORKING) {
                    Button(onClick = {
                        repository.updateStatus(task.id, TaskStatus.COMPLETED)
                    }) { Text("完成任务") }
                }
            }
        }
    }
}

fun statusText(status: TaskStatus): String = when (status) {
    TaskStatus.RECEIVED -> "已接收"
    TaskStatus.ANALYZING -> "AI分析中"
    TaskStatus.ASSIGNED -> "已分配"
    TaskStatus.WORKING -> "AI员工执行中"
    TaskStatus.COMPLETED -> "已完成"
}

@Composable
fun EmployeeCenter() {
    Text("👷 AI员工", style = MaterialTheme.typography.headlineMedium)
    listOf(
        "🤖 AI总管",
        "💻 AI开发员工",
        "💰 AI会计师",
        "🎬 AI内容员工",
        "🔍 AI研究员工",
        "📋 AI任务管理员"
    ).forEach { employee ->
        Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
            Text(employee, modifier = Modifier.padding(16.dp))
        }
    }
}

@Composable
fun AccountantPlaceholder() {
    Text("💰 AI会计师", style = MaterialTheme.typography.headlineMedium)
    Text("下一阶段：收入、支出、税务统计和报税资料管理。")
}
