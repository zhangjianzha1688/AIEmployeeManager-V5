package com.aiemployeemanager.v5.brain

enum class TaskType {
    DEVELOPMENT, ACCOUNTING, CONTENT, RESEARCH, MANAGEMENT, UNKNOWN
}

enum class TaskStatus {
    RECEIVED, ANALYZING, ASSIGNED, WORKING, COMPLETED
}

data class AITask(
    val id: String,
    val userCommand: String,
    val type: TaskType,
    val assignedEmployee: String,
    val status: TaskStatus
)

data class WorkLog(
    val taskId: String,
    val message: String
)
